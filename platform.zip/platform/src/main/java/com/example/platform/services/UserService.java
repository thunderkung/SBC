package com.example.platform.services;

import com.example.platform.entities.User;
import com.sun.java.swing.plaf.windows.WindowsTextAreaUI;
import org.springframework.data.domain.Page;

import java.util.List;
import java.util.Optional;

public interface UserService {
    List<User> findALL();

    Optional<User> findById(Integer id);

    Page<User> finAllByLimit(Integer start, Integer limit, String field);

    List<User> findByCityAndActiveAndAge(String city, Integer active, Integer age);

    List<User> findByAgeIn(List<Integer> ages);

    List<User> findAllByQuery();

    List<User> findAllByParamsQuery(Integer active, String city);

    List<User> findAllByJpqlQuery();

    List<User> findAllByJpqlParamsQuery(Integer active, String city);

    // NEW UserService
    List<User> findAllInactiveByJpqlParamsQuery(String city);

    List<User> findAllByJpqlParamsQueryActiveAge(Integer active, Integer age);


}
