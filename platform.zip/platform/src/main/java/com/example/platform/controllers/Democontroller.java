package com.example.platform.controllers;

import com.example.platform.entities.User;
import com.example.platform.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Array;
import java.net.Inet4Address;
import java.util.*;

@RestController
@RequestMapping("/demo")
public class Democontroller {

    @Autowired
    private UserRepository userRepository;

    @GetMapping(value = "/")
    private String index(){
        List<User> users = userRepository.findAll();
        System.out.println("############### Find All User (In Console) ###############");
        System.out.println(users);
        return "Method GET, Function : index => SHOW data list on page";
    }


    /*@GetMapping(value = "")
    public List<User> index(){
    //public List<User> index(@RequestParam String city,@RequestParam Integer active,@RequestParam Integer age){
        List<User> users =
                userRepository.findByCityAndActiveAndAge("nakornpathom", 1, 18);

        return users;
    }*/

   /* @GetMapping(value = "")
    public List<User> index1() {
        List<Integer> ages = new ArrayList<Integer>(Arrays.asList(18,19,22));
        List<User> users = userRepository.findByAgeIn(ages);

        return users;
    }*/

    @GetMapping(value = "/test1")
    public List<User> test1() {
        return userRepository.findAllByQuery();
    }

    @GetMapping(value = "/test2")
    public List<User> test2() {
        return userRepository.findAllByParamsQuery(0,"nakornpathom");
    }

    @GetMapping(value = "/test2_2")
    public List<User> test2_2(@RequestParam String active,@RequestParam String city) {
        return userRepository.findAllByParamsQuery(Integer.parseInt(active),city);
    }

    @GetMapping(value = "/test3")
    public List<User> test3() {
        return userRepository.findAllByJpqlQuery();
    }

    // Example for findAllByJpqlParamsQuery
    @GetMapping(value = "/test4")
    public List<User> test4() {
        return userRepository.findAllByJpqlParamsQuery(0, "bangkok");
    }


    @GetMapping(value = "/{id}")
    public String showWithPath(@PathVariable String id) {
        Optional<User> user = userRepository.findById(Integer.parseInt(id));
        System.out.println("############### Find User By ID(withPath) ###############");
        System.out.println(user);

        return "(ShowWithParam)Method Get,Function : show ID" + id + " Show data by ID with path";
    }



    @RequestMapping(value = "/healthcheck")
    @ResponseStatus(code = HttpStatus.OK)
    public String healthCheck(){
    /*public String healthCheck(@RequestParam String code, HttpServletResponse response) {
        if("200".equals(code)){
            response.setStatus(HttpServletResponse.SC_);
        }else {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }*/
        return "Hello World!";
    }
   /* @GetMapping(value = "")
    public String index() {
        return "Method GET, Function : index => SHOW data list on page";

  }*/

    /*@GetMapping(value = "")
    public String showWithParam(@RequestParam String id){
        return "Method Get, Function show ID : " + id + " =>SHOW data by id on page with query string";
    }*/

    @PostMapping(value = "")
    public String create(@RequestBody Map<String, Object> inputs){
        System.out.println("########### POST Param ###########");
        System.out.println(inputs);

        return "Method POST, Function : create => INSERT data to DB";
    }

    /*@GetMapping(value = "/{id}")
    public String showWithPath(@PathVariable String id) {
        return "Method Get, Function : Show, ID :" + id +" => SHOW data by id on page with path";
    }*/

    @PatchMapping(value = "/{id}")
    public String update(@PathVariable String id, @RequestBody
            Map<String,String> inputs){
        System.out.println("########### PATCH Param ###########");
                System.out.println(inputs);

        return "Method PATCH, Function : update => ID " + id + "UPDATE data to DB";
    }

    @DeleteMapping(value = "/{id}")
    public String destroy(@PathVariable String id) {
        return "Method DELETE, Function : delete, ID : "+id+" => DELETE data in DB";
    }


}
