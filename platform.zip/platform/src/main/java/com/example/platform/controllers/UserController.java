package com.example.platform.controllers;


import com.example.platform.entities.User;
import com.example.platform.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping(value = "/t1")
    public List<User> t1(){
        return userService.findALL();
    }

    @GetMapping(value = "/t2/{id}")
    public Optional<User> t2(@PathVariable String id) {
        return userService.findById(Integer.parseInt(id));
    }

    @GetMapping(value = "/t3")
    public Page<User> t3(@RequestParam Integer start,@RequestParam Integer limit,@RequestParam String field){
        return userService.finAllByLimit(start, limit, field);
    }

    @GetMapping(value = "/t4")
    public List<User> t4(@RequestParam String city,@RequestParam Integer active,@RequestParam Integer age){
        return userService.findByCityAndActiveAndAge(city, active, age);
    }

    @GetMapping(value = "/t5")
    public List<User> t5(@RequestBody Map<String, Object> ages) {
        //List<Integer> ages = new ArrayList<>(Arrays.asList(20,22,25));
        return userService.findByAgeIn((List<Integer>) ages);
    }

    @GetMapping(value = "/t6")
    public List<User> t6() {
        return userService.findAllByQuery();
    }

    @GetMapping(value = "/t7/{id}")
    public List<User> t7(@PathVariable String id,@RequestParam String city){
        return userService.findAllByJpqlParamsQuery(Integer.parseInt(id),city);
    }

    @GetMapping(value = "/t8")
    public List<User> t8() {
        return userService.findAllByJpqlQuery();
    }

    @GetMapping(value = "/t9/{active}")
    public List<User> t9(@PathVariable String active,@RequestParam String city){
        return userService.findAllByJpqlParamsQuery(Integer.parseInt(active), city);
    }

    // New UserController
    @GetMapping(value = "/new1/{city}")
    public List<User> new1(@PathVariable String city){
        return  userService.findAllInactiveByJpqlParamsQuery(city);
    }

    @GetMapping(value = "/new2")
    public List<User> new2(@RequestParam Integer active, @RequestParam Integer age){
        return userService.findAllByJpqlParamsQueryActiveAge(active, age);
    }

}
